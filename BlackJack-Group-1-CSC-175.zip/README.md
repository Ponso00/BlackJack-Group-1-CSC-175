# BlackJack-Group-1-CSC-175
BLACKJACK
GROUP MEMBERS: Zach Michelson Dane Jarvis, Jacob Wenz

Basic BlackJack created by a group of people in order to practice the collaborative workflow and enviornment of coding with github.
